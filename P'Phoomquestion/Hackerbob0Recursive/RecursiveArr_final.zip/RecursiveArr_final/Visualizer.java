package RecursiveArr_final;

import java.util.ArrayList;


//Do not modify this file
public class Visualizer{
	
	private Object[] arr;

	private int layer;
	private ArrayList<StringBuilder> lines = new ArrayList<>();
	
	/**
	 * this class is for displaying arrays graphically.(more information in the test case)
	 *  
	 * 
	 * @param arr
	 */
	public Visualizer(Object arr) {
		
		if(!arr.getClass().isArray()) {
			System.out.println("NOT ARRAY");
		}
	
		else{
			
			this.arr = (Object[])arr;
			
			layer = new DimensionChecker().dimension(arr);
		}
		
		int count = layer;
			
		for(int i = 0; i < layer; i++) {
			StringBuilder x = new StringBuilder("");
			x.append((count--) +":");
			lines.add(x);
		}
		
	}
	
	
	private void printArr(Object[] arr){	
				
		for(int i = 0; i < arr.length; i++) {
			
			lines.get( new DimensionChecker().dimension(arr)-1 ).append("0");
			
			if(i+1 == arr.length) {
				lines.get( new DimensionChecker().dimension(arr)-1 ).append("|");
			}
			
			try {
				if(arr[i]!=null && arr[i].getClass().isArray()) {
					printArr((Object[])arr[i]);
				}
			}
			catch(Exception e) {
				
			}			
		}
	}
		
	
	
	public void show( ) {
		
		printArr(this.arr);
		
		for(int i = lines.size()-1; i>=0;i-- ) {
			System.out.println(lines.get(i).toString());
		}		
		
	}
	
	
}