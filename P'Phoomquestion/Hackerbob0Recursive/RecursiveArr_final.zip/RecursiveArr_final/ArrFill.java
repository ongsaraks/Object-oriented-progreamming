package RecursiveArr_final;



public class ArrFill{
	/**
	 * This will fill each of the element of the arr ( one dimensional ) with
	 * an Object[] with 'size' length, do this until the input array reaches 'x' dimensions
	 * 
	 * 
	 */
	public ArrFill(){}
	
	public void fillArr( Object[] arr, int size, int x)  {
	//your code here//
		
	}	
	
}
	